import 'package:englify_app/app/app.locator.dart';
import 'package:englify_app/app/app.router.dart';
import 'package:englify_app/services/local_storage_service.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class SplachViewModel extends BaseViewModel {
  final _localstorage = locator<LocalStorageService>();
  final _navigationservice = locator<NavigationService>();

  Future<void> runsetuplogic() async {
    await Future.delayed(Duration(seconds: 3));

    final isfirstlaunch = await _localstorage.isfirstlaunch();

    if (isfirstlaunch) {
      _navigationservice.replaceWithOnbordingView();
      return;
    }
    final role = await _localstorage.getuserrole();
    if (role == null) {
      _navigationservice.replaceWithRoleSelection();
      return;
    }
    final login = await _localstorage.getislogin();
    if (!login) {
      _navigationservice.replaceWithAuthView();
      return;
    }
    if (role == "teacher") {
      _navigationservice.replaceWithTeacherHomeView();
      return;
    }
    final classroomjoin = await _localstorage.isclassroomjoined();
    if (!classroomjoin) {
      _navigationservice.replaceWithPersonalizationView();
      return;
    }
    _navigationservice.replaceWithStudentHomeView();
  }
}




