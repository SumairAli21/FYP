import 'package:flutter/material.dart';

class StudentFavView extends StatelessWidget {
  const StudentFavView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}