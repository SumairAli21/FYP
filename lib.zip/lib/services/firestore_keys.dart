class FirestoreKeys {
  // ===== Collections =====
  static const String classes = 'classes';
  static const String classMembers = 'class_members';
  static const String users = 'users';
  static const String content = 'content';

  // ===== Class fields =====
  static const String className = 'name';
  static const String classDescription = 'description';
  static const String classCode = 'code';
  static const String teacherId = 'teacherId';
  static const String createdAt = 'createdAt';

  // ===== Member fields =====
  static const String classId = 'classId';
  static const String userId = 'userId';
  static const String role = 'role';
  static const String joinedAt = 'joinedAt';

  // ===== Roles =====
  static const String teacher = 'teacher';
  static const String student = 'student';

  // ===== Content fields (future) =====
  static const String title = 'title';
  static const String type = 'type';
  static const String data = 'data';
  static const String order = 'order';
}
