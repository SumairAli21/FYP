import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:englify_app/services/firestore_keys.dart';
import 'package:firebase_core/firebase_core.dart';

class classroomservice {
  final _classes = FirebaseFirestore.instance.collection(FirestoreKeys.classes);
  final _members = FirebaseFirestore.instance.collection(
    FirestoreKeys.classMembers,
  );

  String _generateclasscode() {
    const char = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789';
    final rand = Random();
    return List.generate(6, (_) => char[rand.nextInt(char.length)]).join();
  }

  // teacher create class

  Future<void> createclass({
    required String classname,
    required String teacher_id,
    required String description,
  }) async {
    final code = _generateclasscode();
    final classref = await _classes.add({
      FirestoreKeys.className: classname,
      FirestoreKeys.classDescription: description,
      FirestoreKeys.classCode: code,
      FirestoreKeys.teacherId: teacher_id,
      FirestoreKeys.createdAt: FieldValue.serverTimestamp(),
    });

    await _members.add({
      FirestoreKeys.classId: classref.id,
      FirestoreKeys.userId: teacher_id,
      FirestoreKeys.role: FirestoreKeys.teacher,
      FirestoreKeys.joinedAt: FieldValue.serverTimestamp(),
    });
  }

  Future<String?> joinclass({
    required String classcode,
    required String studentid,
  }) async {
    final result = await _classes
        .where(FirestoreKeys.classCode, isEqualTo: classcode)
        .get();

    if (result.docs.isEmpty) return "invalid class code";

    final classdoc = result.docs.first;

    final exsisting = await _members
        .where(FirestoreKeys.classId, isEqualTo: classdoc.id)
        .where(FirestoreKeys.userId, isEqualTo: studentid)
        .get();

    if (exsisting.docs.isNotEmpty) return "already joined";
    await _members.add({
      FirestoreKeys.classId: classdoc.id,
      FirestoreKeys.userId: studentid,
      FirestoreKeys.role: FirestoreKeys.student,
      FirestoreKeys.joinedAt: FieldValue.serverTimestamp(),
    });
    return null;
  }

  Stream<QuerySnapshot> getstudentclasses(String studentid){
    return _members
    .where(FirestoreKeys.userId, isEqualTo: studentid)
    .where(FirestoreKeys.role, isEqualTo: FirestoreKeys.student)
    .snapshots();
  }

   Stream<QuerySnapshot> getTeacherClasses(String teacherId) {
    return _classes
        .where(FirestoreKeys.teacherId, isEqualTo: teacherId)
        .snapshots();
  }

}
